# Indoor Navigator — Outline Only (Dark + Purple)

Minimalna aplikacja React + Vite wyświetlająca obrys budynku z pliku GeoJSON na mapie MapLibre GL (ciemny motyw + fioletowe akcenty).

## Szybki start (Code Studio / VS Code / lokalnie)

1. **Zainstaluj Node 18+** (w Code Studio zwykle już jest).
2. Otwórz folder projektu.
3. Zainstaluj zależności:
   ```bash
   npm i
   ```
4. Uruchom dev serwer:
   ```bash
   npm run dev
   ```
5. Otwórz podany URL (np. `http://localhost:5173`).

## Własny obrys budynku

- Wrzuć plik GeoJSON do folderu `public/` pod nazwą **`jesus-building.geojson`**.
- Aplikacja automatycznie go wczyta i dopasuje widok (`fitBounds`).

## Build produkcyjny

```bash
npm run build
npm run preview
```

## Struktura

```
public/
  jesus-building.geojson   # tu podmień na swój plik
src/
  App.jsx
  main.jsx
index.html
package.json
```

## Uwaga

Aplikacja jest celowo uproszczona (bez panelu ADM i rysowania) — tylko mapa + obrys budynku.
