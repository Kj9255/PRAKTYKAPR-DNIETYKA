import React, { useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";

const STYLE_DARK = "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json";
const EMPTY_FC = { type: "FeatureCollection", features: [] };

function computeBBoxAny(fc){
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  const push=([x,y])=>{ if(Number.isFinite(x)&&Number.isFinite(y)){ if(x<minX)minX=x; if(y<minY)minY=y; if(x>maxX)maxX=x; if(y>maxY)maxY=y; } };
  const walk=(geom)=>{ if(!geom) return; const t=geom.type;
    if(t==="Point") push(geom.coordinates);
    else if(t==="MultiPoint"||t==="LineString") geom.coordinates.forEach(push);
    else if(t==="MultiLineString"||t==="Polygon") geom.coordinates.flat(1).forEach(push);
    else if(t==="MultiPolygon") geom.coordinates.flat(2).forEach(push);
    else if(t==="GeometryCollection") (geom.geometries||[]).forEach(walk);
  };
  for(const f of fc.features||[]){ walk(f.geometry); }
  if(!Number.isFinite(minX)) return [[0,0],[0,0]];
  return [[minX,minY],[maxX,maxY]];
}

export default function App(){
  const mapRef = useRef(null);
  const [mapReady, setMapReady] = useState(false);
  const [loadError, setLoadError] = useState("");

  useEffect(()=>{
    if(mapRef.current) return;
    const map = new maplibregl.Map({ container:"map", style: STYLE_DARK, center:[0,0], zoom:2, attributionControl:false });
    map.addControl(new maplibregl.NavigationControl({showCompass:false}),"bottom-right");
    map.on("load", ()=>{
      map.addSource("building", { type:"geojson", data: EMPTY_FC });
      map.addLayer({ id:"bldg-fill", type:"fill", source:"building", paint:{ "fill-color":"#7c3aed", "fill-opacity":0.08 } });
      map.addLayer({ id:"bldg-outline", type:"line", source:"building", paint:{ "line-color":"#a78bfa", "line-width": 1.5 } });
      setMapReady(true);
    });
    mapRef.current = map;
    return ()=> map.remove();
  },[]);

  useEffect(()=>{
    if(!mapReady) return;
    (async()=>{
      try{
        const r = await fetch("/jesus-building.geojson");
        if(!r.ok) throw new Error("not found");
        const fc = await r.json();
        const map = mapRef.current;
        const src = map.getSource("building");
        src && src.setData(fc);
        try { const bb = computeBBoxAny(fc); map.fitBounds(bb, { padding: 60, duration: 0 }); } catch {}
        setLoadError("");
      }catch(e){
        setLoadError("Brak pliku /jesus-building.geojson w katalogu public/.");
      }
    })();
  },[mapReady]);

  return (
    <div className="app">
      <div className="topbar">
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:10,height:10,borderRadius:999,background:'#a855f7'}} />
          <div style={{fontWeight:600}}>Indoor Navigator</div>
        </div>
        <div className="badge" style={{marginLeft:'auto'}}>Outline only</div>
      </div>
      <div id="map" style={{flex:1}} />
      {loadError && <div className="error">{loadError}</div>}
    </div>
  );
}

function runSelfTests(){
  try{
    const fc1={type:"FeatureCollection",features:[{type:"Feature",properties:{},geometry:{type:"Polygon",coordinates:[[[0,0],[2,0],[2,1],[0,1],[0,0]]]}}]};
    const b1=computeBBoxAny(fc1);
    console.assert(b1[0][0]===0 && b1[1][1]===1, "bbox polygon");
    const fc2={type:"FeatureCollection",features:[{type:"Feature",properties:{},geometry:{type:"MultiPolygon",coordinates:[[[[0,0],[1,0],[1,1],[0,1],[0,0]]],[[[2,2],[3,2],[3,3],[2,3],[2,2]]]]}}]};
    const b2=computeBBoxAny(fc2);
    console.assert(b2[0][0]===0 && b2[1][1]===3, "bbox multipolygon");
    console.log("Self tests ok");
  }catch(e){ console.warn("Self tests failed", e); }
}
if (typeof window !== "undefined" && !window.__INDOOR_TESTED__) {
  window.__INDOOR_TESTED__ = true;
  setTimeout(runSelfTests, 0);
}
