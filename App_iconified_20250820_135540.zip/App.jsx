// App.jsx
import React, { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import MapboxDraw from '@mapbox/mapbox-gl-draw';
import '@mapbox/mapbox-gl-draw/dist/mapbox-gl-draw.css';
import 'maplibre-gl/dist/maplibre-gl.css';

const DRAW_STYLE = [
  // Polygons (rooms) fill
  {
    id: 'gl-draw-polygon-fill',
    type: 'fill',
    filter: ['all', ['==', '$type', 'Polygon'], ['!=', 'mode', 'static']],
    paint: { 'fill-color': '#1e293b', 'fill-opacity': 0.15 }
  },
  // Polygons outline
  {
    id: 'gl-draw-polygon-outline',
    type: 'line',
    filter: ['all', ['==', '$type', 'Polygon'], ['!=', 'mode', 'static']],
    paint: { 'line-color': '#7c3aed', 'line-width': 2 }
  },
  // Lines (paths/corridors)
  {
    id: 'gl-draw-line-path',
    type: 'line',
    filter: ['all', ['==', '$type', 'LineString'], ['!=', 'mode', 'static']],
    paint: { 'line-color': '#3b3b3b', 'line-width': 3 }
  },
  // Fallback small dot only for points WITHOUT 'kind'
  {
    id: 'gl-draw-point-any',
    type: 'circle',
    filter: ['all', ['==', '$type', 'Point'], ['!', ['has', 'kind']]],
    paint: { 'circle-radius': 4, 'circle-color': '#650070' }
  },
  // Icons for points WITH 'kind'
  {
    id: 'gl-draw-point-icons',
    type: 'symbol',
    filter: ['all', ['==', '$type', 'Point'], ['has', 'kind']],
    layout: {
      'icon-image': [
        'match', ['get', 'kind'],
        'extinguisher', 'extinguisher-icon',
        'hose',         'hose-icon',
        'hydrant',      'hydrant-icon',
        'assembly',     'assembly-icon',
        'exit',         'exit-icon',
        'door',         'door-icon',
        /* default */   'marker-icon'
      ],
      'icon-size': 1.0,
      'icon-allow-overlap': true,
      'text-field': ['coalesce', ['get', 'name'], ''],
      'text-size': 12,
      'text-offset': [0, 1.0],
      'text-anchor': 'top'
    },
    paint: {}
  }
];

export default function App() {
  const mapRef = useRef(null);
  const drawRef = useRef(null);

  const [currentKind, setCurrentKind] = useState('extinguisher');
  const currentKindRef = useRef(currentKind);
  useEffect(() => { currentKindRef.current = currentKind; }, [currentKind]);

  const labelForKind = (kind) => ({
    extinguisher: 'Gaśnica',
    hose: 'Wąż',
    hydrant: 'Hydrant',
    assembly: 'Punkt zbiórki',
    exit: 'Wyjście',
    door: 'Drzwi'
  }[kind] || kind);

  useEffect(() => {
    if (mapRef.current) return;

    const map = new maplibregl.Map({
      container: 'map',
      style: 'https://demotiles.maplibre.org/style.json',
      center: [21.0122, 52.2297],
      zoom: 15
    });
    mapRef.current = map;

    const draw = new MapboxDraw({
      displayControlsDefault: false,
      controls: { point: true, line_string: true, polygon: true, trash: true },
      styles: DRAW_STYLE
    });
    drawRef.current = draw;
    map.addControl(draw, 'top-left');

    map.on('load', () => {
      // Load icon PNGs from public/icons/
      const iconMap = {
        'extinguisher-icon': new URL('icons/extinguisher.png', document.baseURI).href,
        'hose-icon':         new URL('icons/hose.png',         document.baseURI).href,
        'hydrant-icon':      new URL('icons/hydrant.png',      document.baseURI).href,
        'assembly-icon':     new URL('icons/assembly.png',     document.baseURI).href,
        'exit-icon':         new URL('icons/exit.png',         document.baseURI).href,
        'door-icon':         new URL('icons/door.png',         document.baseURI).href,
        'marker-icon':       new URL('icons/marker.png',       document.baseURI).href
      };

      const loadIcons = () => {
        Object.entries(iconMap).forEach(([name, url]) => {
          if (map.hasImage(name)) return;
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => {
            try { if (!map.hasImage(name)) map.addImage(name, img); } catch (e) { console.error('addImage failed', name, e); }
          };
          img.onerror = (e) => console.warn('Icon missing or failed to load:', name, url, e);
          img.src = url;
        });
      };

      loadIcons();

      map.on('styleimagemissing', (e) => {
        const missing = e && e.id;
        const known = Object.keys(iconMap);
        if (typeof missing === 'string' && known.includes(missing) && !map.hasImage(missing)) {
          loadIcons();
        }
      });
    });

    // When a point is created, set its kind & label
    map.on('draw.create', (e) => {
      e.features.forEach((f) => {
        if (f.geometry?.type === 'Point') {
          const kind = currentKindRef.current || 'extinguisher';
          draw.setFeatureProperty(f.id, 'kind', kind);
          draw.setFeatureProperty(f.id, 'name', labelForKind(kind));
        }
      });
    });

    return () => { if (map) map.remove(); };
  }, []);

  const buttons = [
    { key: 'extinguisher', label: 'Gaśnica' },
    { key: 'hose',         label: 'Wąż' },
    { key: 'hydrant',      label: 'Hydrant' },
    { key: 'assembly',     label: 'Zbiórka' },
    { key: 'exit',         label: 'Wyjście' },
    { key: 'door',         label: 'Drzwi' }
  ];

  return (
    <div style={{ height: '100vh', width: '100%', position: 'relative' }}>
      <div
        style={{
          position: 'absolute',
          top: 8,
          right: 8,
          zIndex: 1,
          background: 'white',
          padding: 8,
          borderRadius: 8,
          boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
          display: 'flex',
          gap: 6
        }}
      >
        {buttons.map(btn => (
          <button
            key={btn.key}
            onClick={() => setCurrentKind(btn.key)}
            style={{
              padding: '6px 10px',
              borderRadius: 6,
              border: '1px solid #ddd',
              cursor: 'pointer',
              background: currentKind === btn.key ? '#f1f5f9' : 'white'
            }}
            title={`Ustaw typ: ${btn.label}, potem użyj narzędzia Punkt w Draw i kliknij na mapie`}
          >
            {btn.label}
          </button>
        ))}
      </div>
      <div id="map" style={{ height: '100%', width: '100%' }} />
    </div>
  );
}
