App.jsx (iconified points) — 20250820_135540

Jak używać:
1) Zainstaluj zależności:
   npm i maplibre-gl @mapbox/mapbox-gl-draw

2) Umieść w public/icons/ pliki PNG:
   - extinguisher.png
   - hose.png
   - hydrant.png
   - assembly.png
   - exit.png
   - door.png
   - marker.png  (fallback)

3) Uruchom serwer statyczny (np. http-server) i otwórz stronę z App.jsx (w bundlerze/CRA/Vite).

Jak to działa:
- Punkty z properties.kind renderują się jako ikony (warstwa 'gl-draw-point-icons').
- Punkty bez 'kind' to mała kropka (fallback).
- Pasek przycisków w prawym górnym rogu ustawia bieżący 'kind' dla nowo rysowanych punktów.
